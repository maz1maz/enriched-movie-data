import json
import time
import requests
from pathlib import Path
import csv
import re, html

CACHE_PATH = "/home/user/output/tvmaze_cache.json"
CSV_PATH_ENRICHED = "/home/user/output/series-movies-enriched.csv"
OUTPUT_XLSX = "/home/user/output/series-movies-enriched.xlsx"
OUTPUT_CSV = "/home/user/output/series-movies-enriched.csv"

# Corrections: title -> correct show ID
CORRECTIONS = {
    "Money Heist": 27436,  # La Casa de Papel
    "Protector": 36807,    # The Protector Turkish
    "The Bridge (Bron-Breon)": 1910,  # Bron / Broen
    "The Protector": 36807, # just in case
}

def strip_html(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', '', text)
    return html.unescape(text).strip()

def extract_fields(show, crew, cast):
    year = ""
    if show.get("premiered"):
        m = re.search(r'^(19\d{2}|20\d{2})', show["premiered"])
        if m:
            year = m.group(1)
    genre = ", ".join(show.get("genres", []))
    rating = ""
    if show.get("rating") and show["rating"].get("average") is not None:
        rating = str(show["rating"]["average"])
    runtime = ""
    if show.get("runtime"):
        runtime = f"{show['runtime']} min"
    elif show.get("averageRuntime"):
        runtime = f"{show['averageRuntime']} min"
    country = ""
    studio = ""
    if show.get("network"):
        if show["network"].get("country") and show["network"]["country"].get("name"):
            country = show["network"]["country"]["name"]
        studio = show["network"].get("name", "")
    if show.get("webChannel"):
        if not country and show["webChannel"].get("country") and show["webChannel"]["country"].get("name"):
            country = show["webChannel"]["country"]["name"]
        if not studio:
            studio = show["webChannel"].get("name", "")
        if not country and show["webChannel"]["name"] in ["Netflix", "Hulu", "Amazon Prime Video", "Apple TV+", "Disney+"]:
            country = "United States"
    if not country:
        lang = show.get("language", "")
        if lang == "English":
            country = "United States"
        elif lang == "Korean":
            country = "South Korea"
        elif lang == "Spanish":
            country = "Spain"
        elif lang == "Turkish":
            country = "Turkey"
        elif lang == "Swedish":
            country = "Sweden"
    synopsis = strip_html(show.get("summary", ""))
    poster = ""
    if show.get("image"):
        poster = show["image"].get("original") or show["image"].get("medium") or ""
    producers = []
    directors = []
    creators = []
    for member in crew:
        t = member.get("type", "")
        name = member.get("person", {}).get("name", "")
        if not name:
            continue
        if "Producer" in t:
            producers.append(name)
        if "Director" in t:
            directors.append(name)
        if "Creator" in t:
            creators.append(name)
    producer_str = ", ".join(list(dict.fromkeys(producers))[:5])
    director_str = ", ".join(list(dict.fromkeys(directors))[:3])
    if not director_str and creators:
        director_str = ", ".join(list(dict.fromkeys(creators))[:3])
    cast_str = ", ".join([c.get("person", {}).get("name", "") for c in cast[:8] if c.get("person", {}).get("name")])
    if not producer_str and creators:
        producer_str = ", ".join(creators[:3])
    return {
        "Year": year,
        "Genre": genre,
        "Rating": rating,
        "Runtime": runtime,
        "Country": country,
        "Studio": studio,
        "Synopsis": synopsis,
        "Poster URL": poster,
        "Producer": producer_str,
        "Director": director_str,
        "Cast": cast_str,
        "_show_name": show.get("name"),
        "_premiered": show.get("premiered")
    }

session = requests.Session()
cache = json.loads(Path(CACHE_PATH).read_text(encoding='utf-8'))

for title, correct_id in CORRECTIONS.items():
    if title not in cache:
        print(f"Title {title} not in cache, skipping correction")
        continue
    print(f"Correcting {title} -> ID {correct_id}")
    # fetch correct show
    r = session.get(f"https://api.tvmaze.com/shows/{correct_id}", timeout=10)
    if r.status_code != 200:
        print(f"Failed to fetch show {correct_id}")
        continue
    show = r.json()
    time.sleep(0.3)
    r = session.get(f"https://api.tvmaze.com/shows/{correct_id}/crew", timeout=10)
    crew = r.json() if r.status_code==200 else []
    time.sleep(0.3)
    r = session.get(f"https://api.tvmaze.com/shows/{correct_id}/cast", timeout=10)
    cast = r.json() if r.status_code==200 else []
    time.sleep(0.3)
    cache[title] = {"show": show, "crew": crew, "cast": cast, "query": f"corrected-{correct_id}"}
    print(f"  Corrected to: {show['name']} {show.get('premiered')}")

# Save cache
Path(CACHE_PATH).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

# Now re-read original uploaded csv to get base?
# Actually we need to rebuild enriched from original csv + cache
ORIGINAL_CSV = "/home/user/uploads/series-movies-archive-export (1).csv"

rows = []
for enc in ['windows-1252', 'utf-8-sig', 'latin-1']:
    try:
        import csv
        with open(ORIGINAL_CSV, 'r', encoding=enc) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            print(f"Read original with {enc}: {len(rows)}")
            break
    except Exception as e:
        print(e)

enriched = []
for row in rows:
    title = row.get("Title","").strip()
    if title in cache:
        show = cache[title]["show"]
        crew = cache[title].get("crew", [])
        cast_l = cache[title].get("cast", [])
        extra = extract_fields(show, crew, cast_l)
        new_row = row.copy()
        for k in ["Producer","Director","Cast","Year","Genre","Rating","Runtime","Country","Studio","Synopsis","Poster URL"]:
            new_row[k] = extra.get(k,"") or row.get(k,"")
        enriched.append(new_row)
    else:
        enriched.append(row)

# Write outputs
with open(OUTPUT_CSV, 'w', encoding='utf-8-sig', newline='') as out_f:
    writer = csv.DictWriter(out_f, fieldnames=enriched[0].keys())
    writer.writeheader()
    writer.writerows(enriched)
print(f"CSV rewritten: {OUTPUT_CSV}")

# XLSX
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Series Archive"
fieldnames = list(enriched[0].keys())
for col_idx, fn in enumerate(fieldnames, 1):
    cell = ws.cell(row=1, column=col_idx, value=fn)
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
    cell.alignment = Alignment(horizontal="center", vertical="center")
for r_idx, r in enumerate(enriched, 2):
    for c_idx, fn in enumerate(fieldnames, 1):
        ws.cell(row=r_idx, column=c_idx, value=r.get(fn,""))
for col_idx, fn in enumerate(fieldnames, 1):
    ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = 25
ws.freeze_panes = "A2"
ws.auto_filter.ref = ws.dimensions
wb.save(OUTPUT_XLSX)
print(f"XLSX rewritten: {OUTPUT_XLSX}")
