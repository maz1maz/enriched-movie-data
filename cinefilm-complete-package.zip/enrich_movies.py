import csv
import json
import time
import re
import requests
from pathlib import Path

INPUT_CSV = "/home/user/uploads/movies.csv"
OUTPUT_XLSX = "/home/user/output/movies-enriched.xlsx"
OUTPUT_CSV = "/home/user/output/movies-enriched.csv"
CACHE_PATH = "/home/user/output/omdb_cache.json"

OMDB_API_KEY = "thewdb"  # public demo key, works
OMDB_URL = "https://www.omdbapi.com/"

def clean_title(raw):
    t = raw.strip()
    # Remove weird artifacts
    t = re.sub(r'\s+', ' ', t)
    # Remove year in parentheses if present in title? Keep original for search but cleaned for fallback
    # Common cleaning
    # e.g., "Duel (TV Movie" -> "Duel"
    t = re.sub(r'\s*\(TV Movie.*$', '', t, flags=re.I)
    t = re.sub(r'\s*\(Video.*$', '', t, flags=re.I)
    t = re.sub(r'�', '', t)
    # For titles like "Se rokh" after english? Keep only english part before double space?
    # Example "3 Faces  Se rokh" -> use "3 Faces"
    if '  ' in raw:
        # try split double space
        parts = raw.split('  ')
        # take first non-empty
        if parts[0].strip():
            # But we will try both: full and first part
            pass
    return t.strip()

def get_search_variants(movie_title, release_year):
    variants = []
    # Original
    variants.append(movie_title)
    # Cleaned
    cleaned = clean_title(movie_title)
    if cleaned != movie_title and cleaned not in variants:
        variants.append(cleaned)
    # First part before double space
    if '  ' in movie_title:
        first = movie_title.split('  ')[0].strip()
        if first and first not in variants:
            variants.append(first)
    # Remove punctuation tricky
    # e.g., "A Pigeon Sat on a Branch Reflecting on Existence" is long but ok
    # For titles with comma like "A Minute To Pray, A Second To Die" keep
    # Also try removing apostrophes?
    return variants

def fetch_omdb(title, year, session, cache):
    cache_key = f"{title}___{year}"
    if cache_key in cache:
        return cache[cache_key]

    # Try variants
    variants = get_search_variants(title, year)
    for var_title in variants:
        # Try with year if year is valid
        tried_params = []
        if year and str(year).strip().upper() != "N/A" and re.match(r'^\d{4}$', str(year).strip()):
            tried_params.append({"t": var_title, "y": str(year).strip()})
        tried_params.append({"t": var_title})

        for params in tried_params:
            params.update({"apikey": OMDB_API_KEY, "plot": "full"})
            try:
                resp = session.get(OMDB_URL, params=params, timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("Response") == "True":
                        cache[cache_key] = data
                        print(f"  Found via t='{var_title}' y='{params.get('y','')}' -> {data.get('Title')} ({data.get('Year')})")
                        time.sleep(0.3)  # be nice
                        return data
                    else:
                        # Not found, try search
                        pass
            except Exception as e:
                print(f"  Error t={var_title} y={params.get('y')}: {e}")
            time.sleep(0.2)

        # Try search endpoint s=
        try:
            params = {"apikey": OMDB_API_KEY, "s": var_title}
            if year and str(year).strip().upper() != "N/A" and re.match(r'^\d{4}$', str(year).strip()):
                params["y"] = str(year).strip()
            resp = session.get(OMDB_URL, params=params, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("Response") == "True" and data.get("Search"):
                    # Take first result
                    first = data["Search"][0]
                    imdb_id = first.get("imdbID")
                    if imdb_id:
                        # Now fetch by id
                        params2 = {"apikey": OMDB_API_KEY, "i": imdb_id, "plot": "full"}
                        r2 = session.get(OMDB_URL, params=params2, timeout=10)
                        if r2.status_code == 200:
                            data2 = r2.json()
                            if data2.get("Response") == "True":
                                cache[cache_key] = data2
                                print(f"  Found via search s='{var_title}' -> {data2.get('Title')} ({data2.get('Year')})")
                                time.sleep(0.3)
                                return data2
        except Exception as e:
            print(f"  Search error s={var_title}: {e}")
        time.sleep(0.2)

    print(f"  !! NOT FOUND: {title} ({year})")
    cache[cache_key] = {"Response": "False", "Error": "Not found", "Title": title, "Year": year}
    return cache[cache_key]

def main():
    input_path = Path(INPUT_CSV)
    out_dir = Path(OUTPUT_CSV).parent
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load cache
    cache = {}
    if Path(CACHE_PATH).exists():
        try:
            cache = json.loads(Path(CACHE_PATH).read_text(encoding='utf-8'))
            print(f"Loaded cache with {len(cache)} entries")
        except:
            cache = {}

    session = requests.Session()
    session.headers.update({"User-Agent": "MovieEnricher/1.0"})

    # Read input CSV - try encodings
    rows = []
    for enc in ['utf-8-sig', 'windows-1252', 'cp1252', 'latin-1']:
        try:
            with open(input_path, 'r', encoding=enc) as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                print(f"Read {len(rows)} movies with encoding {enc}")
                break
        except Exception as e:
            print(f"Failed enc {enc}: {e}")
            continue

    if not rows:
        print("No rows!")
        return

    enriched = []
    total = len(rows)
    found_count = 0

    for idx, row in enumerate(rows, 1):
        movie_title = row.get("Movie Title", "").strip()
        release_year = row.get("Release Year", "").strip()
        if not movie_title:
            continue
        print(f"[{idx}/{total}] {movie_title} ({release_year})")

        data = fetch_omdb(movie_title, release_year, session, cache)

        # Build output row according to image: Title, Shelf, Row, Director, Cast, Year, Genre, Rating, Runtime, Country, Synopsis, Poster URL, Original Title
        # Shelf and Row not in source, leave blank
        # Original Title = data Title? Or original input? Use OMDB Title as original, and Movie Title as Title? Spec says Title and Original Title - let's set Title = Movie Title input, Original Title = OMDB Title (or same)
        # But better set Title = Movie Title (as in archive), Original Title = OMDB Title (could be same or English original)
        omdb_title = data.get("Title", "") if data.get("Response") == "True" else ""
        director = data.get("Director", "") if data.get("Response") == "True" else ""
        cast = data.get("Actors", "") if data.get("Response") == "True" else ""
        year = data.get("Year", "") if data.get("Response") == "True" else release_year
        # Year might be "2000–" for series, clean to first 4 digits
        if year:
            m = re.search(r'(\d{4})', year)
            if m:
                year = m.group(1)
        genre = data.get("Genre", "") if data.get("Response") == "True" else ""
        rating = data.get("imdbRating", "") if data.get("Response") == "True" else ""
        runtime = data.get("Runtime", "") if data.get("Response") == "True" else ""
        country = data.get("Country", "") if data.get("Response") == "True" else ""
        synopsis = data.get("Plot", "") if data.get("Response") == "True" else ""
        poster = data.get("Poster", "") if data.get("Response") == "True" else ""
        if poster == "N/A":
            poster = ""

        # Clean director N/A
        if director == "N/A":
            director = ""
        if cast == "N/A":
            cast = ""
        if genre == "N/A":
            genre = ""
        if rating == "N/A":
            rating = ""
        if runtime == "N/A":
            runtime = ""
        if country == "N/A":
            country = ""
        if synopsis == "N/A":
            synopsis = ""

        if data.get("Response") == "True":
            found_count += 1

        out_row = {
            "Title": movie_title,
            "Shelf": "",  # Not available in source
            "Row": "",    # Not available
            "Director": director,
            "Cast": cast,
            "Year": year,
            "Genre": genre,
            "Rating": rating,
            "Runtime": runtime,
            "Country": country,
            "Synopsis": synopsis,
            "Poster URL": poster,
            "Original Title": omdb_title or movie_title,
            # Extra for reference - keep original file info?
            "Source_Year": release_year,
            "Total Size": row.get("Total Size",""),
            "Resolutions": row.get("Resolutions",""),
        }
        enriched.append(out_row)

        # Save cache periodically
        if idx % 20 == 0:
            Path(CACHE_PATH).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')
            print(f"  Cache saved, found {found_count}/{idx}")

    # Final cache save
    Path(CACHE_PATH).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

    # Write CSV
    fieldnames = ["Title", "Shelf", "Row", "Director", "Cast", "Year", "Genre", "Rating", "Runtime", "Country", "Synopsis", "Poster URL", "Original Title", "Source_Year", "Total Size", "Resolutions"]
    with open(OUTPUT_CSV, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(enriched)
    print(f"CSV written: {OUTPUT_CSV} with {len(enriched)} rows, found {found_count}")

    # Write XLSX
    try:
        import openpyxl
        from openpyxl.styles import Font, Alignment, PatternFill
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Movies Archive"

        for col_idx, fn in enumerate(fieldnames, 1):
            cell = ws.cell(row=1, column=col_idx, value=fn)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        for r_idx, r in enumerate(enriched, 2):
            for c_idx, fn in enumerate(fieldnames, 1):
                val = r.get(fn, "")
                # Truncate synopsis for display? Keep full
                ws.cell(row=r_idx, column=c_idx, value=val)

        # Adjust widths
        widths = {
            "Title": 30,
            "Shelf": 8,
            "Row": 8,
            "Director": 25,
            "Cast": 40,
            "Year": 8,
            "Genre": 25,
            "Rating": 8,
            "Runtime": 12,
            "Country": 20,
            "Synopsis": 60,
            "Poster URL": 50,
            "Original Title": 30,
            "Source_Year": 12,
            "Total Size": 12,
            "Resolutions": 12,
        }
        for col_idx, fn in enumerate(fieldnames, 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = widths.get(fn, 20)

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions

        wb.save(OUTPUT_XLSX)
        print(f"XLSX written: {OUTPUT_XLSX}")
    except Exception as e:
        print(f"XLSX failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
