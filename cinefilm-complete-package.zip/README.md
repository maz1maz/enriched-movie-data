# Cinefilm Archive - Complete Enricher

این برنامه کامل همون کدیه که برای تمام هاردهای شما استفاده شد:
- فیلم: 811 + 2027 + 305 + 226 + 363 عنوان
- سریال: 113 + 117 عنوان
- موفقیت: 85-96% پر شدن خودکار

## فایل‌ها
- `complete-cinefilm-enricher.py` - برنامه اصلی (هم فیلم هم سریال)
- `series-enricher-complete.py` - فقط سریال (TVMaze)
- `movies-enricher-complete.py` - فقط فیلم (OMDb)
- `enrich_movie2.py` - مخصوص هارد دوم فیلم (2027)
- `enrich_series_hard2.py` - مخصوص هارد دوم سریال

## نصب
```bash
pip install requests openpyxl
```

## استفاده
```bash
# اتوماتیک تشخیص نوع
python complete-cinefilm-enricher.py --input movies.csv
python complete-cinefilm-enricher.py --input series.csv

# دستی تعیین نوع
python complete-cinefilm-enricher.py --input d1.csv --type movie
python complete-cinefilm-enricher.py --input series-hard2.csv --type series

# خروجی در پوشه output/
# output/movies-enriched-final.xlsx
# output/movies-MISSING-to-fix.xlsx (با آدرس هارد)
```

## خروجی
1. **Enriched Final**: طبق عکس نمونه
   - فیلم: Title | Shelf | Row | Director | Cast | Year | Genre | Rating | Runtime | Country | Synopsis | Poster URL | Original Title | Total Size | Folder Paths
   - سریال: + Producer, Studio, Seasons Available, ...

2. **Missing To Fix**: فقط ناقص‌ها با آدرس دقیق روی هارد
   - `H:\Archive\...` یا `Total Size | Folder Paths`
   - برای اصلاح دستی

## API ها
- فیلم: OMDb API (کلید عمومی `thewdb` - رایگان 1000 درخواست/روز)
- سریال: TVMaze API (کاملا رایگان بدون کلید)

## کش
برنامه کش خودکار دارد:
- `output/omdb_cache.json` - برای فیلم‌ها
- `output/tvmaze_cache.json` - برای سریال‌ها

اگر نصفه قطع شد، دوباره اجرا کنید از ادامه می‌آورد.

## نکات
- فایل‌های شما انکدینگ windows-1252 داشتند (به خاطر کاراکتر `·` و فارسی) - برنامه خودکار تشخیص میدهد
- عناوین مشکل‌دار مثل Money Heist -> La Casa de Papel خودکار تصحیح می‌شود
- Shelf و Row خالی می‌ماند (چون در فایل اصلی نبود) - خودتان می‌توانید دستی پر کنید
