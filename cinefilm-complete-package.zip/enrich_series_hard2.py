import csv, json, re, time, html
from pathlib import Path
import requests

INPUT = "/home/user/uploads/series.csv"
OUTPUT_XLSX = "/home/user/output/series-hard2-enriched.xlsx"
OUTPUT_CSV = "/home/user/output/series-hard2-enriched.csv"
CACHE = "/home/user/output/tvmaze_cache.json"

CORRECTIONS = {
    "Money Heist": 27436,
    "Protector": 36807,
    "The Protector": 36807,
    "The Bridge (Bron-Breon)": 1910,
    "Anne": 12989,
    "24": 406,  # 24 id
}

def clean_search_title(raw):
    t=str(raw).strip()
    t=re.sub(r'\s+S\s*\d+.*$','',t,flags=re.I)
    t=re.sub(r'\s+Season\s*\d+.*$','',t,flags=re.I)
    return re.sub(r'\s+',' ',t).strip()

def get_paren_stripped(t):
    return re.sub(r'\s*\(.*?\)\s*',' ',t).strip()

def strip_html(text):
    if not text:
        return ""
    text=re.sub(r'<[^>]+>','',text)
    return html.unescape(text).strip()

def fetch_tvmaze_search(title, session):
    candidates=[]
    if title=="Anne":
        candidates=["Anne with an E","Anne","Anne 2017"]
    elif title=="24":
        candidates=["24","24 TV series"]
    elif title=="Kingdom":
        candidates=["Kingdom Korean","Kingdom 2019","Kingdom"]
    elif title=="Money Heist":
        candidates=["La Casa de Papel","Money Heist"]
    elif title=="Protector":
        candidates=["Hakan Muhafiz","The Protector 2018"]
    elif "Bridge" in title:
        candidates=["Bron Broen","The Bridge",title]
    elif title=="A":
        candidates=["A Season in Hakkari"]
    else:
        candidates.append(title)
        cleaned=clean_search_title(title)
        if cleaned!=title:
            candidates.append(cleaned)
        stripped=get_paren_stripped(cleaned)
        if stripped!=cleaned and stripped!=title:
            candidates.append(stripped)
    # dedup
    seen=[]
    for c in candidates:
        if c not in seen and c.strip():
            seen.append(c)
    candidates=seen

    for q in candidates:
        try:
            resp=session.get("https://api.tvmaze.com/search/shows", params={"q":q}, timeout=10)
            if resp.status_code==200:
                results=resp.json()
                if results:
                    if title in CORRECTIONS:
                        target=CORRECTIONS[title]
                        for item in results:
                            if item['show']['id']==target:
                                return item['show'], q, results
                    return results[0]['show'], q, results
        except Exception as e:
            print(f" search fail {q}: {e}")
        time.sleep(0.4)
    return None,None,[]

def fetch_crew_cast(show_id, session):
    crew,cast=[],[]
    try:
        r=session.get(f"https://api.tvmaze.com/shows/{show_id}/crew", timeout=10)
        if r.status_code==200:
            crew=r.json()
    except: pass
    time.sleep(0.25)
    try:
        r=session.get(f"https://api.tvmaze.com/shows/{show_id}/cast", timeout=10)
        if r.status_code==200:
            cast=r.json()
    except: pass
    time.sleep(0.25)
    return crew,cast

def fetch_by_id(show_id, session):
    try:
        r=session.get(f"https://api.tvmaze.com/shows/{show_id}", timeout=10)
        if r.status_code==200:
            return r.json()
    except: pass
    return None

def extract_fields(show, crew, cast):
    year=""
    if show.get("premiered"):
        m=re.search(r'^(19\d{2}|20\d{2})', show["premiered"])
        if m: year=m.group(1)
    genre=", ".join(show.get("genres",[]))
    rating=str(show["rating"]["average"]) if show.get("rating") and show["rating"].get("average") is not None else ""
    runtime=f"{show['runtime']} min" if show.get("runtime") else f"{show['averageRuntime']} min" if show.get("averageRuntime") else ""
    country,studio="",""
    if show.get("network"):
        if show["network"].get("country"):
            country=show["network"]["country"].get("name","")
        studio=show["network"].get("name","")
    if show.get("webChannel"):
        if not country and show["webChannel"].get("country"):
            country=show["webChannel"]["country"].get("name","")
        if not studio:
            studio=show["webChannel"].get("name","")
        if not country and show["webChannel"]["name"] in ["Netflix","Hulu","Amazon Prime Video","Apple TV+","Disney+"]:
            country="United States"
    if not country:
        lang_map={"English":"United States","Korean":"South Korea","Spanish":"Spain","Turkish":"Turkey","Swedish":"Sweden","Japanese":"Japan","French":"France","German":"Germany"}
        country=lang_map.get(show.get("language",""), show.get("language",""))
    synopsis=strip_html(show.get("summary",""))
    poster=(show.get("image") or {}).get("original") or (show.get("image") or {}).get("medium") or ""
    producers, directors, creators=[],[],[]
    for member in crew:
        t=member.get("type","")
        name=member.get("person",{}).get("name","")
        if not name: continue
        if "Producer" in t: producers.append(name)
        if "Director" in t: directors.append(name)
        if "Creator" in t: creators.append(name)
    producer_str=", ".join(list(dict.fromkeys(producers))[:5])
    director_str=", ".join(list(dict.fromkeys(directors))[:3])
    if not director_str and creators:
        director_str=", ".join(list(dict.fromkeys(creators))[:3])
    cast_str=", ".join([c.get("person",{}).get("name","") for c in cast[:8] if c.get("person",{}).get("name")])
    if not producer_str and creators:
        producer_str=", ".join(creators[:3])
    return {
        "Year": year,
        "Genre": genre,
        "Rating": rating,
        "Runtime": runtime,
        "Country": country,
        "Studio": studio,
        "Synopsis": synopsis,
        "Poster URL": poster,
        "Producer": producer_str,
        "Director": director_str,
        "Cast": cast_str,
    }

# Load cache
cache={}
if Path(CACHE).exists():
    try:
        cache=json.loads(Path(CACHE).read_text(encoding='utf-8'))
        print(f"Cache loaded {len(cache)}")
    except: pass

session=requests.Session()
session.headers.update({"User-Agent":"SeriesEnricher/1.0"})

# Read input
rows=[]
with open(INPUT,'r',encoding='utf-8-sig') as f:
    reader=csv.DictReader(f)
    print(f"Fieldnames: {reader.fieldnames}")
    for r in reader:
        # r keys: No., Series Name, Seasons Available, Total Episodes, Resolutions, Audio / Version, Total Size, Season & Episode Breakdown, Sample Folder Path
        # Some have empty Series Name
        title=r.get("Series Name","").strip()
        # Also handle first broken rows?
        if not title:
            # try to infer from Sample Folder Path?
            # e.g., "Season For Assassins 1975"
            sample=r.get("Sample Folder Path","")
            # Try extract
            # Skip if still empty or generic
            if not sample:
                continue
            # Skip rows where title empty and sample is Season For Assassins etc? Actually that might be title
            # If title empty, use folder basename
            # Parse folder: H:\\Archive\\5576Season For Assassins 1975 -> Season For Assassins
            import os
            # Very rough
            # But we'll skip empty titles for now
            continue
        rows.append(r)

print(f"Parsed {len(rows)} series")

enriched=[]
for idx,row in enumerate(rows,1):
    title=row.get("Series Name","").strip()
    print(f"[{idx}/{len(rows)}] {title}")

    show=None
    crew,cast_list=[],[]

    # correction direct fetch
    if title in CORRECTIONS and title not in cache:
        print(f"  -> correction ID {CORRECTIONS[title]}")
        show=fetch_by_id(CORRECTIONS[title], session)
        if show:
            crew,cast_list=fetch_crew_cast(show['id'], session)
            cache[title]={"show":show,"crew":crew,"cast":cast_list,"query":f"correction-{CORRECTIONS[title]}"}

    if title in cache:
        show=cache[title]["show"]
        crew=cache[title].get("crew",[])
        cast_list=cache[title].get("cast",[])
        print(f"  -> cache {show.get('name')} ({show.get('premiered')})")
    else:
        if not show:
            show,used_q,_=fetch_tvmaze_search(title, session)
        if not show:
            print(f"  !! NOT FOUND {title}")
            # keep original with empty enriched fields
            new_row=row.copy()
            for k in ["Producer","Director","Cast","Year","Genre","Rating","Runtime","Country","Studio","Synopsis","Poster URL"]:
                new_row[k]=""
            enriched.append(new_row)
            continue
        print(f"  -> found via '{used_q}': {show.get('name')} ({show.get('premiered')})")
        crew,cast_list=fetch_crew_cast(show['id'], session)
        cache[title]={"show":show,"crew":crew,"cast":cast_list,"query":used_q}
        if idx%10==0:
            Path(CACHE).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

    extra=extract_fields(show, crew, cast_list)
    new_row=row.copy()
    # Add enriched fields
    for k,v in extra.items():
        new_row[k]=v
    enriched.append(new_row)
    Path(CACHE).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')
    time.sleep(0.15)

# Write outputs
if enriched:
    # fieldnames = original + enriched new ones
    original_fields=list(rows[0].keys()) if rows else []
    extra_fields=["Producer","Director","Cast","Year","Genre","Rating","Runtime","Country","Studio","Synopsis","Poster URL"]
    all_fields=original_fields+ [f for f in extra_fields if f not in original_fields]

    with open(OUTPUT_CSV,'w',encoding='utf-8-sig',newline='') as out_f:
        writer=csv.DictWriter(out_f, fieldnames=all_fields)
        writer.writeheader()
        writer.writerows(enriched)
    print(f"CSV -> {OUTPUT_CSV}")

    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
        wb=openpyxl.Workbook()
        ws=wb.active
        ws.title="Series Hard2"
        for ci,fn in enumerate(all_fields,1):
            c=ws.cell(row=1,column=ci,value=fn)
            c.font=Font(bold=True,color="FFFFFF")
            c.fill=PatternFill(start_color="2F5597",end_color="2F5597",fill_type="solid")
            c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        for ri,r in enumerate(enriched,2):
            for ci,fn in enumerate(all_fields,1):
                ws.cell(row=ri,column=ci,value=r.get(fn,""))
        for ci,fn in enumerate(all_fields,1):
            ws.column_dimensions[get_column_letter(ci)].width=25 if fn not in ["Synopsis","Season & Episode Breakdown","Sample Folder Path"] else 60
        ws.freeze_panes="A2"
        ws.auto_filter.ref=ws.dimensions
        wb.save(OUTPUT_XLSX)
        print(f"XLSX -> {OUTPUT_XLSX}")
    except Exception as e:
        print(e)
        import traceback; traceback.print_exc()
