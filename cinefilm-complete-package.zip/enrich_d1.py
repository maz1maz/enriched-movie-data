import csv, json, re, time
from pathlib import Path
import requests

INPUT = "/home/user/uploads/d1.csv"
OUTPUT_FINAL_XLSX = "/home/user/output/d1-enriched-final.xlsx"
OUTPUT_FINAL_CSV = "/home/user/output/d1-enriched-final.csv"
CACHE = "/home/user/output/omdb_cache.json"

OMDB_API_KEY = "thewdb"
OMDB_URL = "https://www.omdbapi.com/"

IMAGE_COLS = ["Title","Shelf","Row","Director","Cast","Year","Genre","Rating","Runtime","Country","Synopsis","Poster URL","Original Title"]

def clean_title(t):
    t = t.strip()
    t = re.sub(r'\s+', ' ', t)
    t = re.sub(r'\s*\(TV Movie.*$', '', t, flags=re.I)
    t = t.replace('�','').strip()
    return t

def get_variants(title):
    v=[title]
    c=clean_title(title)
    if c!=title and c not in v:
        v.append(c)
    if '  ' in title:
        first=title.split('  ')[0].strip()
        if first and first not in v:
            v.append(first)
    return v

def fetch_omdb(title, year, session, cache):
    key=f"{title}___{year}"
    if key in cache:
        return cache[key]
    for var in get_variants(title):
        tries=[]
        if year and re.match(r'^\d{4}$', str(year).strip()):
            tries.append({"t": var, "y": str(year).strip()})
        tries.append({"t": var})
        for params in tries:
            params.update({"apikey": OMDB_API_KEY, "plot":"full"})
            try:
                r=session.get(OMDB_URL, params=params, timeout=12)
                if r.status_code==200:
                    d=r.json()
                    if d.get("Response")=="True":
                        cache[key]=d
                        print(f"  Found t='{var}' y='{params.get('y','')}' -> {d.get('Title')} ({d.get('Year')})")
                        time.sleep(0.35)
                        return d
            except Exception as e:
                print(f" err {e}")
            time.sleep(0.2)
        # search
        try:
            params={"apikey":OMDB_API_KEY,"s":var}
            if year and re.match(r'^\d{4}$', str(year).strip()):
                params["y"]=str(year).strip()
            r=session.get(OMDB_URL, params=params, timeout=12)
            if r.status_code==200:
                d=r.json()
                if d.get("Response")=="True" and d.get("Search"):
                    imdb_id=d["Search"][0].get("imdbID")
                    if imdb_id:
                        r2=session.get(OMDB_URL, params={"apikey":OMDB_API_KEY,"i":imdb_id,"plot":"full"}, timeout=12)
                        if r2.status_code==200:
                            d2=r2.json()
                            if d2.get("Response")=="True":
                                cache[key]=d2
                                print(f"  Found via search s='{var}' -> {d2.get('Title')} ({d2.get('Year')})")
                                time.sleep(0.35)
                                return d2
        except Exception as e:
            print(f" search err {e}")
        time.sleep(0.2)
    print(f"  !! NOT FOUND {title} ({year})")
    cache[key]={"Response":"False","Error":"Not found","Title":title,"Year":year}
    return cache[key]

# Load cache
cache={}
if Path(CACHE).exists():
    try:
        cache=json.loads(Path(CACHE).read_text(encoding='utf-8'))
        print(f"Cache loaded {len(cache)}")
    except:
        pass

session=requests.Session()
session.headers.update({"User-Agent":"MoviesEnricher/1.0"})

rows=[]
# d1.csv has garbled header but data is simple: read as plain without header assumption
# Try to detect header
for enc in ['windows-1252','windows-1256','utf-8-sig','latin-1']:
    try:
        with open(INPUT,'r',encoding=enc) as f:
            reader=csv.reader(f)
            all_rows=list(reader)
        # First row should have 6 cols
        print(f"Read {len(all_rows)} raw rows with {enc}, header={all_rows[0]}")
        # If first row second column is like 'Das Boot', it's data not header? But first row first col is ???? which is header
        # We'll assume first row is header and data starts at 1
        header=all_rows[0]
        data_rows=all_rows[1:]
        # Parse
        temp=[]
        for r in data_rows:
            if len(r)<3:
                continue
            # r[0]=num, r[1]=title, r[2]=year
            title=r[1].strip() if len(r)>1 else ""
            year=r[2].strip() if len(r)>2 else ""
            if title:
                temp.append({"num":r[0], "title":title, "year":year, "raw":r})
        rows=temp
        print(f"Parsed {len(rows)} movies")
        break
    except Exception as e:
        print(f"fail {enc}: {e}")

enriched=[]
found=0
for idx, item in enumerate(rows,1):
    title=item["title"]
    year=item["year"]
    print(f"[{idx}/{len(rows)}] {title} ({year})")
    data=fetch_omdb(title, year, session, cache)
    is_ok=data.get("Response")=="True"
    if is_ok:
        found+=1
    def gc(k):
        v=data.get(k,"") if is_ok else ""
        return "" if v=="N/A" else v
    omdb_title=gc("Title")
    director=gc("Director")
    cast=gc("Actors")
    y_raw=gc("Year") or year
    m=re.search(r'(\d{4})', y_raw) if y_raw else None
    y=m.group(1) if m else y_raw
    genre=gc("Genre")
    rating=gc("imdbRating")
    runtime=gc("Runtime")
    country=gc("Country")
    synopsis=gc("Plot")
    poster=gc("Poster")

    out={
        "Title": title,
        "Shelf": "",
        "Row": "",
        "Director": director,
        "Cast": cast,
        "Year": y,
        "Genre": genre,
        "Rating": rating,
        "Runtime": runtime,
        "Country": country,
        "Synopsis": synopsis,
        "Poster URL": poster,
        "Original Title": omdb_title or title,
    }
    enriched.append(out)

    if idx % 20==0:
        Path(CACHE).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f" cache saved found {found}/{idx}")

Path(CACHE).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

# Write final
import csv as csvm
with open(OUTPUT_FINAL_CSV,'w',encoding='utf-8-sig',newline='') as f:
    w=csvm.DictWriter(f, fieldnames=IMAGE_COLS)
    w.writeheader()
    w.writerows(enriched)
print(f"CSV -> {OUTPUT_FINAL_CSV} found {found}/{len(rows)}")

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    wb=openpyxl.Workbook()
    ws=wb.active
    ws.title="Movies"
    for ci, fn in enumerate(IMAGE_COLS,1):
        c=ws.cell(row=1,column=ci,value=fn)
        c.font=Font(bold=True,color="FFFFFF")
        c.fill=PatternFill(start_color="2F5597",end_color="2F5597",fill_type="solid")
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    for ri, r in enumerate(enriched,2):
        for ci, fn in enumerate(IMAGE_COLS,1):
            ws.cell(row=ri,column=ci,value=r.get(fn,""))
    widths={"Title":32,"Shelf":8,"Row":8,"Director":26,"Cast":45,"Year":8,"Genre":28,"Rating":8,"Runtime":12,"Country":22,"Synopsis":70,"Poster URL":50,"Original Title":32}
    for ci, fn in enumerate(IMAGE_COLS,1):
        ws.column_dimensions[get_column_letter(ci)].width=widths.get(fn,20)
    ws.freeze_panes="A2"
    ws.auto_filter.ref=ws.dimensions
    wb.save(OUTPUT_FINAL_XLSX)
    print(f"XLSX -> {OUTPUT_FINAL_XLSX}")
except Exception as e:
    print(e)
    import traceback; traceback.print_exc()

print(f"Done {found}/{len(rows)} {found/len(rows)*100:.1f}%")
