import csv, json, re, time
from pathlib import Path
import requests

INPUT = "/home/user/uploads/movie2.csv"
OUTPUT_XLSX = "/home/user/output/movie2-hard2-enriched-final.xlsx"
OUTPUT_CSV = "/home/user/output/movie2-hard2-enriched-final.csv"
MISSING_CSV = "/home/user/output/missing-movie2-hard2.csv"
CACHE = "/home/user/output/omdb_cache.json"

OMDB_API_KEY="thewdb"
OMDB_URL="https://www.omdbapi.com/"
IMAGE_COLS=["Title","Shelf","Row","Director","Cast","Year","Genre","Rating","Runtime","Country","Synopsis","Poster URL","Original Title","Total Size","Folder Paths"]

def clean_title(t):
    t=t.strip()
    t=re.sub(r'\s+',' ',t)
    t=re.sub(r'\s*\(TV Movie.*$','',t,flags=re.I)
    t=re.sub(r'\s*\(Video.*$','',t,flags=re.I)
    return t.replace('�','').strip()

def get_variants(title):
    v=[title]
    c=clean_title(title)
    if c!=title and c not in v:
        v.append(c)
    if '  ' in title:
        first=title.split('  ')[0].strip()
        if first and first not in v:
            v.append(first)
    # Remove year like "Movie Title (year)"? Keep
    return v

def fetch_omdb(title, year, session, cache):
    key=f"{title}___{year}"
    if key in cache:
        return cache[key]
    # Also try generic key without year if exists and success?
    # Check any cache starting with title___
    for ck in list(cache.keys()):
        if ck.startswith(f"{title}___") and cache[ck].get("Response")=="True":
            # Use first successful variant as fallback to save API call
            # But prefer exact year
            if ck==key:
                return cache[ck]
    # Try exact search only if not in cache
    for var in get_variants(title):
        tries=[]
        if year and re.match(r'^\d{4}$', str(year).strip()):
            tries.append({"t":var,"y":str(year).strip()})
        tries.append({"t":var})
        for params in tries:
            params.update({"apikey":OMDB_API_KEY,"plot":"full"})
            try:
                r=session.get(OMDB_URL, params=params, timeout=12)
                if r.status_code==200:
                    d=r.json()
                    if d.get("Response")=="True":
                        cache[key]=d
                        print(f"  Found t='{var}' y='{params.get('y','')}' -> {d.get('Title')} ({d.get('Year')})")
                        time.sleep(0.35)
                        return d
            except Exception as e:
                print(f"  err {e}")
            time.sleep(0.2)
        try:
            params={"apikey":OMDB_API_KEY,"s":var}
            if year and re.match(r'^\d{4}$', str(year).strip()):
                params["y"]=str(year).strip()
            r=session.get(OMDB_URL, params=params, timeout=12)
            if r.status_code==200:
                d=r.json()
                if d.get("Response")=="True" and d.get("Search"):
                    imdb_id=d["Search"][0].get("imdbID")
                    if imdb_id:
                        r2=session.get(OMDB_URL, params={"apikey":OMDB_API_KEY,"i":imdb_id,"plot":"full"}, timeout=12)
                        if r2.status_code==200:
                            d2=r2.json()
                            if d2.get("Response")=="True":
                                cache[key]=d2
                                print(f"  Found via search s='{var}' -> {d2.get('Title')} ({d2.get('Year')})")
                                time.sleep(0.35)
                                return d2
        except Exception as e:
            print(f"  search err {e}")
        time.sleep(0.2)
    print(f"  !! NOT FOUND {title} ({year})")
    cache[key]={"Response":"False","Error":"Not found","Title":title,"Year":year}
    return cache[key]

# Load cache
cache={}
if Path(CACHE).exists():
    try:
        cache=json.loads(Path(CACHE).read_text(encoding='utf-8'))
        print(f"Cache loaded {len(cache)}")
    except:
        pass

session=requests.Session()
session.headers.update({"User-Agent":"MoviesEnricher/1.0"})

rows=[]
with open(INPUT,'r',encoding='windows-1252') as f:
    reader=csv.DictReader(f)
    rows=list(reader)
print(f"Parsed {len(rows)} movies")

enriched=[]
missing=[]
found=0

for idx,row in enumerate(rows,1):
    title=row.get("Movie Title","").strip()
    year=row.get("Release Year","").strip()
    if not title:
        continue
    print(f"[{idx}/{len(rows)}] {title} ({year})")
    data=fetch_omdb(title, year, session, cache)
    is_ok=data.get("Response")=="True"
    if is_ok:
        found+=1
    else:
        missing.append({
            "Title": title,
            "Year": year,
            "Total Size": row.get("Total Size",""),
            "Folder Paths": row.get("Folder Paths",""),
            "Reason": "در OMDb پیدا نشد - لطفا نام را اصلاح کنید"
        })

    def gc(k):
        v=data.get(k,"") if is_ok else ""
        return "" if v=="N/A" else v

    omdb_title=gc("Title")
    director=gc("Director")
    cast=gc("Actors")
    y_raw=gc("Year") or year
    m=re.search(r'(\d{4})', y_raw) if y_raw else None
    y=m.group(1) if m else y_raw
    genre=gc("Genre")
    rating=gc("imdbRating")
    runtime=gc("Runtime")
    country=gc("Country")
    synopsis=gc("Plot")
    poster=gc("Poster")

    out={
        "Title": title,
        "Shelf": "",
        "Row": "",
        "Director": director,
        "Cast": cast,
        "Year": y,
        "Genre": genre,
        "Rating": rating,
        "Runtime": runtime,
        "Country": country,
        "Synopsis": synopsis,
        "Poster URL": poster,
        "Original Title": omdb_title or title,
        "Total Size": row.get("Total Size",""),
        "Folder Paths": row.get("Folder Paths",""),
    }
    enriched.append(out)

    if idx%30==0:
        Path(CACHE).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f"  >> Cache saved {found}/{idx} - missing so far {len(missing)}")

Path(CACHE).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

# Write final
with open(OUTPUT_CSV,'w',encoding='utf-8-sig',newline='') as f:
    import csv as csvm
    w=csvm.DictWriter(f, fieldnames=IMAGE_COLS)
    w.writeheader()
    w.writerows(enriched)
print(f"CSV -> {OUTPUT_CSV} found {found}/{len(enriched)}")

# Missing CSV
with open(MISSING_CSV,'w',encoding='utf-8-sig',newline='') as f:
    import csv as csvm
    w=csvm.DictWriter(f, fieldnames=["Title","Year","Total Size","Folder Paths","Reason"])
    w.writeheader()
    w.writerows(missing)
print(f"Missing -> {MISSING_CSV} {len(missing)}")

# XLSX
try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    wb=openpyxl.Workbook()
    ws=wb.active
    ws.title="Movies_Hard2"
    for ci,fn in enumerate(IMAGE_COLS,1):
        c=ws.cell(row=1,column=ci,value=fn)
        c.font=Font(bold=True,color="FFFFFF")
        c.fill=PatternFill(start_color="2F5597",end_color="2F5597",fill_type="solid")
        c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    for ri,r in enumerate(enriched,2):
        for ci,fn in enumerate(IMAGE_COLS,1):
            ws.cell(row=ri,column=ci,value=r.get(fn,""))
    widths={"Title":32,"Shelf":8,"Row":8,"Director":26,"Cast":45,"Year":8,"Genre":28,"Rating":8,"Runtime":12,"Country":22,"Synopsis":70,"Poster URL":50,"Original Title":32,"Total Size":12,"Folder Paths":80}
    for ci,fn in enumerate(IMAGE_COLS,1):
        ws.column_dimensions[get_column_letter(ci)].width=widths.get(fn,20)
    ws.freeze_panes="A2"
    ws.auto_filter.ref=ws.dimensions
    wb.save(OUTPUT_XLSX)
    print(f"XLSX -> {OUTPUT_XLSX}")

    # Missing XLSX also
    wb2=openpyxl.Workbook()
    ws2=wb2.active
    ws2.title="Missing_To_Fix"
    missing_fields=["Title","Year","Total Size","Folder Paths","Reason"]
    for ci,fn in enumerate(missing_fields,1):
        c=ws2.cell(row=1,column=ci,value=fn)
        c.font=Font(bold=True,color="FFFFFF")
        c.fill=PatternFill(start_color="C00000",end_color="C00000",fill_type="solid")
    for ri,r in enumerate(missing,2):
        for ci,fn in enumerate(missing_fields,1):
            ws2.cell(row=ri,column=ci,value=r.get(fn,""))
    for ci in range(1, len(missing_fields)+1):
        ws2.column_dimensions[get_column_letter(ci)].width=30
    ws2.column_dimensions['D'].width=80
    wb2.save(OUTPUT_XLSX.replace(".xlsx","-MISSING.xlsx"))
    print(f"Missing XLSX -> {OUTPUT_XLSX.replace('.xlsx','-MISSING.xlsx')}")

except Exception as e:
    print(e)
    import traceback; traceback.print_exc()

print(f"FINAL Done {found}/{len(enriched)} = {found/len(enriched)*100:.1f}% success, missing {len(missing)}")
