import csv
import re
import json
import time
import html
from pathlib import Path
import requests
from collections import defaultdict

CSV_PATH = "/home/user/uploads/series-movies-archive-export (1).csv"
OUTPUT_XLSX = "/home/user/output/series-movies-enriched.xlsx"
OUTPUT_CSV = "/home/user/output/series-movies-enriched.csv"
CACHE_PATH = "/home/user/output/tvmaze_cache.json"

# Title cleaning for better search
def clean_search_title(raw_title):
    t = raw_title.strip()
    # Handle special cases
    # "Stranger Things S 03" -> "Stranger Things"
    t = re.sub(r'\s+S\s*\d+.*$', '', t, flags=re.I)  # S 03
    t = re.sub(r'\s+Season\s*\d+.*$', '', t, flags=re.I)
    t = re.sub(r'\s+Series\s*\d+.*$', '', t, flags=re.I)
    # Remove parentheses content for search but keep main
    # e.g., "The Bridge (Bron-Breon)" -> search "The Bridge"
    # We'll try original first, then stripped
    t = t.strip()
    # Remove extra spaces
    t = re.sub(r'\s+', ' ', t)
    return t

def get_paranthesis_stripped(title):
    # Remove (...) 
    return re.sub(r'\s*\(.*?\)\s*', ' ', title).strip()

def strip_html(text):
    if not text:
        return ""
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    return text.strip()

def fetch_tvmaze_search(title, session):
    # Try original, then cleaned, then stripped parenth
    candidates = []
    candidates.append(title)
    cleaned = clean_search_title(title)
    if cleaned != title:
        candidates.append(cleaned)
    stripped = get_paranthesis_stripped(cleaned)
    if stripped != cleaned and stripped != title:
        candidates.append(stripped)
    # Special hard-coded disambiguations
    special = {
        "24": "24",
        "Anne": "Anne with an E",
        "Kingdom": "Kingdom 2019",
        "The Bridge (Bron-Breon)": "The Bridge",
        "Elite": "Elite",
        "After Life": "After Life",
    }
    if title in special:
        candidates.insert(0, special[title])
        # also add variant
        if title == "Anne":
            candidates = ["Anne with an E", "Anne", "Anne 2017"]
        if title == "24":
            candidates = ["24", "24 TV series"]
        if title == "Kingdom":
            candidates = ["Kingdom Korean", "Kingdom", "Kingdom 2019"]

    for q in candidates:
        try:
            resp = session.get(f"https://api.tvmaze.com/search/shows", params={"q": q}, timeout=10)
            if resp.status_code == 200:
                results = resp.json()
                if results:
                    # Return best match
                    return results[0]['show'], q, results
        except Exception as e:
            print(f" Search failed for {q}: {e}")
        time.sleep(0.4)
    return None, None, []

def fetch_crew_cast(show_id, session):
    crew = []
    cast = []
    try:
        r = session.get(f"https://api.tvmaze.com/shows/{show_id}/crew", timeout=10)
        if r.status_code == 200:
            crew = r.json()
    except Exception as e:
        print(f" crew fetch failed {show_id}: {e}")
    time.sleep(0.3)
    try:
        r = session.get(f"https://api.tvmaze.com/shows/{show_id}/cast", timeout=10)
        if r.status_code == 200:
            cast = r.json()
    except Exception as e:
        print(f" cast fetch failed {show_id}: {e}")
    time.sleep(0.3)
    return crew, cast

def extract_fields(show, crew, cast):
    # Year from premiered
    year = ""
    if show.get("premiered"):
        m = re.search(r'^(19\d{2}|20\d{2})', show["premiered"])
        if m:
            year = m.group(1)

    genre = ", ".join(show.get("genres", []))

    rating = ""
    if show.get("rating") and show["rating"].get("average") is not None:
        rating = str(show["rating"]["average"])

    runtime = ""
    if show.get("runtime"):
        runtime = f"{show['runtime']} min"
    elif show.get("averageRuntime"):
        runtime = f"{show['averageRuntime']} min"

    country = ""
    studio = ""
    # network
    if show.get("network"):
        if show["network"].get("country") and show["network"]["country"].get("name"):
            country = show["network"]["country"]["name"]
        studio = show["network"].get("name", "")
    if show.get("webChannel"):
        if not country and show["webChannel"].get("country") and show["webChannel"]["country"].get("name"):
            country = show["webChannel"]["country"]["name"]
        if not studio:
            studio = show["webChannel"].get("name", "")
        # For Netflix etc, country often US
        if not country and show["webChannel"]["name"] in ["Netflix", "Hulu", "Amazon Prime Video", "Apple TV+", "Disney+"]:
            country = "United States"
    if not country:
        lang = show.get("language", "")
        if lang == "English":
            country = "United States"
        elif lang == "Korean":
            country = "South Korea"
        elif lang == "Spanish":
            country = "Spain"
        # etc default

    synopsis = strip_html(show.get("summary", ""))

    poster = ""
    if show.get("image"):
        poster = show["image"].get("original") or show["image"].get("medium") or ""

    # Crew parsing
    producers = []
    directors = []
    creators = []
    # TVMaze crew types: Executive Producer, Producer, Co-Producer, Creator, Director etc
    for member in crew:
        t = member.get("type", "")
        name = member.get("person", {}).get("name", "")
        if not name:
            continue
        if "Producer" in t:
            producers.append(name)
        if "Director" in t:
            directors.append(name)
        if "Creator" in t:
            creators.append(name)
        if "Writer" in t or "Created" in t:
            # sometimes?
            pass

    # If no director but creators exist, use creator as director/producer hint
    producer_str = ", ".join(list(dict.fromkeys(producers))[:5])
    director_str = ", ".join(list(dict.fromkeys(directors))[:3])
    if not director_str and creators:
        director_str = ", ".join(list(dict.fromkeys(creators))[:3])

    cast_str = ", ".join([c.get("person", {}).get("name", "") for c in cast[:8] if c.get("person", {}).get("name")])

    # If producers empty, try to use creator
    if not producer_str and creators:
        producer_str = ", ".join(creators[:3])

    return {
        "Year": year,
        "Genre": genre,
        "Rating": rating,
        "Runtime": runtime,
        "Country": country,
        "Studio": studio,
        "Synopsis": synopsis,
        "Poster URL": poster,
        "Producer": producer_str,
        "Director": director_str,
        "Cast": cast_str,
    }

def main():
    csv_path = Path(CSV_PATH)
    out_dir = Path(OUTPUT_XLSX).parent
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load cache
    cache = {}
    if Path(CACHE_PATH).exists():
        try:
            cache = json.loads(Path(CACHE_PATH).read_text(encoding='utf-8'))
        except:
            cache = {}

    session = requests.Session()
    session.headers.update({"User-Agent": "MovieCatalogBot/1.0"})

    rows = []
    # Try multiple encodings due to · character
    for enc in ['utf-8-sig', 'windows-1252', 'cp1252', 'latin-1']:
        try:
            with open(csv_path, 'r', encoding=enc) as f:
                reader = csv.DictReader(f)
                original_fieldnames = reader.fieldnames
                temp_rows = list(reader)
            rows = temp_rows
            print(f"Read CSV with encoding {enc}, rows={len(rows)}")
            break
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"Failed with {enc}: {e}")
            continue
    if not rows:
        print("Failed to read CSV")
        return

    enriched_rows = []
    total = len(rows)
    print(f"Total shows: {total}")

    for idx, row in enumerate(rows, 1):
        title = row.get("Title", "").strip()
        if not title:
            enriched_rows.append(row)
            continue

        print(f"[{idx}/{total}] Processing: {title}")

        # Check cache
        if title in cache and cache[title].get("show"):
            show = cache[title]["show"]
            crew = cache[title].get("crew", [])
            cast_list = cache[title].get("cast", [])
            print(f"  -> from cache: {show.get('name')} ({show.get('premiered')})")
        else:
            show, used_query, results = fetch_tvmaze_search(title, session)
            if not show:
                print(f"  !! Not found: {title}")
                # keep original row
                enriched_rows.append(row)
                # save cache miss to avoid re-search? No
                continue
            print(f"  -> found via '{used_query}': {show.get('name')} ({show.get('premiered')}) [score search]")
            crew, cast_list = fetch_crew_cast(show["id"], session)
            # save to cache
            cache[title] = {"show": show, "crew": crew, "cast": cast_list, "query": used_query}
            # periodically save cache
            if idx % 10 == 0:
                Path(CACHE_PATH).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

        extra = extract_fields(show, crew, cast_list)

        # Merge: only fill if original empty
        new_row = row.copy()
        for k in ["Producer", "Director", "Cast", "Year", "Genre", "Rating", "Runtime", "Country", "Studio", "Synopsis", "Poster URL"]:
            original_val = str(row.get(k, "")).strip()
            new_val = extra.get(k, "")
            if not original_val and new_val:
                new_row[k] = new_val
            elif k in ["Year", "Genre", "Rating", "Runtime", "Country", "Studio", "Synopsis", "Poster URL", "Producer", "Director", "Cast"]:
                # If original empty string or just whitespace, fill; otherwise if we have better data, overwrite? User said incomplete, so fill only empty.
                # But we will fill if original is empty; if not empty keep original? We decided to overwrite with richer data if original empty.
                # Actually user said "ناقصه رو پر کن" so we keep existing and fill missing. So we already did.
                # However for fields that are empty in CSV (all of them), we fill.
                if not original_val:
                    new_row[k] = new_val
        # Also ensure Year as int? Keep string
        enriched_rows.append(new_row)

        # Save cache every iteration for safety
        Path(CACHE_PATH).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

        # Be nice to API
        time.sleep(0.2)

    # Final cache save
    Path(CACHE_PATH).write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding='utf-8')

    # Write enriched CSV
    if enriched_rows:
        fieldnames = list(enriched_rows[0].keys())
        with open(OUTPUT_CSV, 'w', encoding='utf-8-sig', newline='') as out_f:
            writer = csv.DictWriter(out_f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(enriched_rows)
        print(f"CSV written: {OUTPUT_CSV}")

        # Write XLSX
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Series Archive"

            # Header
            for col_idx, fn in enumerate(fieldnames, 1):
                cell = ws.cell(row=1, column=col_idx, value=fn)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
                cell.alignment = Alignment(horizontal="center", vertical="center")

            for r_idx, r in enumerate(enriched_rows, 2):
                for c_idx, fn in enumerate(fieldnames, 1):
                    ws.cell(row=r_idx, column=c_idx, value=r.get(fn, ""))

            # Auto width (approx)
            for col_idx, fn in enumerate(fieldnames, 1):
                max_len = len(fn)
                for r in enriched_rows[:50]:
                    v = str(r.get(fn, ""))[:100]
                    if len(v) > max_len:
                        max_len = len(v)
                ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = min(max_len + 2, 50)

            # Freeze top row
            ws.freeze_panes = "A2"
            # Filter
            ws.auto_filter.ref = ws.dimensions

            wb.save(OUTPUT_XLSX)
            print(f"XLSX written: {OUTPUT_XLSX}")
        except Exception as e:
            print(f"Failed to write XLSX: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    main()
