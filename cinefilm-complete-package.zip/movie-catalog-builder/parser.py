import re
from pathlib import Path

QUALITY_PATTERNS = [
    (r'(2160p|4k|UHD)', '4K'),
    (r'(1080p|1080)', '1080p'),
    (r'(720p|720)', '720p'),
    (r'(480p|480)', '480p'),
    (r'(360p)', '360p'),
]

SOURCE_PATTERNS = [
    (r'BluRay|Blu-Ray|BDRip|BRRip|BD', 'BluRay'),
    (r'WEB-DL|WEBDL|WEB', 'WEB-DL'),
    (r'HDRip', 'HDRip'),
    (r'DVDRip', 'DVDRip'),
    (r'CAM|HDCAM', 'CAM'),
    (r'TS|Telesync', 'TS'),
    (r'HEVC|x265|H\.265', 'HEVC/x265'),
    (r'x264|H\.264|AVC', 'x264'),
    (r'10bit|10-bit', '10bit'),
    (r'HDR|HDR10', 'HDR'),
    (r'Dolby|Atmos|TrueHD|DTS', 'High Audio')
]

YEAR_PATTERN = re.compile(r'(?:\(|\[|\s)(19\d{2}|20[0-2]\d)(?:\)|\]|\s|\.|$)')
# Clean title extraction

def parse_filename(filepath: Path):
    filename = filepath.stem
    parent = str(filepath.parent)
    
    # size will be handled outside
    original_name = filepath.name
    
    # Detect quality
    quality = "Unknown"
    for pat, label in QUALITY_PATTERNS:
        if re.search(pat, original_name, re.I):
            quality = label
            break

    # Detect source/codec
    sources = []
    for pat, label in SOURCE_PATTERNS:
        if re.search(pat, original_name, re.I):
            sources.append(label)
    source_str = ", ".join(list(dict.fromkeys(sources)))  # dedup

    # Detect year
    year_match = YEAR_PATTERN.search(original_name)
    year = int(year_match.group(1)) if year_match else None

    # Build clean title for TMDB
    # Remove year, quality, source, brackets, dots, underscores
    clean = filename
    
    # Replace dots and underscores with space if it looks like torrent name
    if clean.count('.') > 2 or '_' in clean:
        clean = re.sub(r'[._]', ' ', clean)
    
    # Remove year
    clean = YEAR_PATTERN.sub(' ', clean)
    
    # Remove quality & common tags
    tags_to_remove = [
        r'1080p|720p|2160p|4k|480p|360p', 
        r'BluRay|BDRip|BRRip|WEB-DL|WEBDL|HDRip|DVDRip|WEBRip|WEB|Blu-Ray',
        r'x264|x265|HEVC|H264|H265|10bit|HDR|AAC|AC3|DTS|TrueHD|Atmos|5\.1|7\.1',
        r'YIFY|YTS|RARBG|ETRG|Ganool|PSA|Pahe|YALO|GalaxyRG|Tigole',
        r'Extended|Unrated|Directors Cut|Remastered|REPACK|PROPER|LIMITED',
        r'\[.*?\]|\(.*?\)|\{.*?\}'
    ]
    for pat in tags_to_remove:
        clean = re.sub(pat, ' ', clean, flags=re.I)
    
    clean = re.sub(r'\s+', ' ', clean).strip()
    # Remove leading/trailing dash
    clean = re.sub(r'^[\s\-]+|[\s\-]+$', '', clean)
    
    # Title case
    # If clean still too long, take first 3-4 words? no, keep full
    
    return {
        "original_filename": original_name,
        "clean_title": clean,
        "quality": quality,
        "source": source_str,
        "year": year,
        "folder": parent,
        "extension": filepath.suffix.lower()
    }
