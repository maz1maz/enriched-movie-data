#!/usr/bin/env python3
"""
Cinefilm Archive - Complete Enricher
=====================================
یه برنامه کامل برای پر کردن اطلاعات ناقص آرشیو فیلم و سریال

این همون کدیه که برای هارد اول و دومت استفاده کردم:
- 811 فیلم + 2027 فیلم هارد دوم + 305 + 226 + 363 + 117 سریال = ~4000 عنوان

ویژگی‌ها:
- تشخیص خودکار نوع فایل (فیلم یا سریال)
- برای فیلم‌ها: OMDb API (IMDb) - کلید عمومی thewdb
- برای سریال‌ها: TVMaze API (رایگان بدون کلید)
- کش خودکار برای جلوگیری از درخواست تکراری
- خروجی اکسل طبق عکس: Title | Shelf | Row | Director | Cast | Year | Genre | Rating | Runtime | Country | Synopsis | Poster URL | Original Title
- لیست ناقص‌ها با آدرس دقیق روی هارد برای اصلاح دستی

نویسنده: ساخته شده برای آرشیو شما

Requirements:
    pip install requests openpyxl

Usage:
    python complete-cinefilm-enricher.py --input movies.csv
    python complete-cinefilm-enricher.py --input series.csv
    python complete-cinefilm-enricher.py --input d1.csv --type movie
    python complete-cinefilm-enricher.py --input series-hard2.csv --type series
"""

import argparse
import csv
import json
import re
import time
import html
from pathlib import Path
import requests
from collections import defaultdict

# --- CONFIG ---
OMDB_API_KEY = "thewdb"  # کلید عمومی - 1000 درخواست در روز
OMDB_URL = "https://www.omdbapi.com/"
TVMAZE_SEARCH_URL = "https://api.tvmaze.com/search/shows"
TVMAZE_SHOW_URL = "https://api.tvmaze.com/shows/{}"
TVMAZE_CREW_URL = "https://api.tvmaze.com/shows/{}/crew"
TVMAZE_CAST_URL = "https://api.tvmaze.com/shows/{}/cast"

# ستون‌های نهایی طبق عکس نمونه
MOVIE_IMAGE_COLS = ["Title","Shelf","Row","Director","Cast","Year","Genre","Rating","Runtime","Country","Synopsis","Poster URL","Original Title","Total Size","Folder Paths"]
SERIES_IMAGE_COLS = ["Title","Shelf","Row","Director","Cast","Year","Genre","Rating","Runtime","Country","Synopsis","Poster URL","Original Title","Seasons Available","Total Size","Sample Folder Path"]

# --- TVMaze Corrections برای عناوین مشکل‌دار ---
TVMAZE_CORRECTIONS = {
    "Money Heist": 27436,               # La Casa de Papel اصلی
    "Protector": 36807,                 # نسخه ترکی 2018
    "The Protector": 36807,
    "The Bridge (Bron-Breon)": 1910,    # Bron / Broen سوئدی
    "Anne": 12989,                      # Anne with an E
    "24": 406,
}

# =============================================================================
# Utility Functions
# =============================================================================
def strip_html(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', '', text)
    return html.unescape(text).strip()

def clean_title_movie(title):
    t = title.strip()
    t = re.sub(r'\s+', ' ', t)
    t = re.sub(r'\s*\(TV Movie.*$', '', t, flags=re.I)
    t = re.sub(r'\s*\(Video.*$', '', t, flags=re.I)
    t = t.replace('�','').replace('³','3').strip()
    return t

def clean_title_series(title):
    t = title.strip()
    t = re.sub(r'\s+S\s*\d+.*$', '', t, flags=re.I)  # Stranger Things S 03 -> Stranger Things
    t = re.sub(r'\s+Season\s*\d+.*$', '', t, flags=re.I)
    return re.sub(r'\s+', ' ', t).strip()

def get_paren_stripped(title):
    return re.sub(r'\s*\(.*?\)\s*', ' ', title).strip()

def parse_year_genre_from_details(details):
    year, genre = "", ""
    if not details:
        return year, genre
    m = re.search(r'Year:\s*(\d{4})', details)
    if m:
        year = m.group(1)
    m2 = re.search(r'Genre:\s*(.*)', details)
    if m2:
        genre = m2.group(1).strip()
    return year, genre

def detect_file_type(csv_path):
    """تشخیص خودکار فیلم یا سریال بر اساس هدر"""
    with open(csv_path, 'r', encoding='windows-1252', errors='ignore') as f:
        reader = csv.reader(f)
        rows = list(reader)
        if not rows:
            return "movie"
        header = ",".join(rows[0]).lower()
        header2 = ",".join(rows[3]).lower() if len(rows)>3 else ""
        # Series indicators
        if "series name" in header or "seasons available" in header or "seasons available" in header2:
            return "series"
        if "seasons" in header and "drive" in header:
            return "series"
        if "movie title" in header and "folder paths" in header:
            return "movie"
        # Fallback: check first data row structure
        return "movie"

# =============================================================================
# OMDb (Movies)
# =============================================================================
def fetch_omdb(title, year, session, cache):
    key = f"{title}___{year}"
    if key in cache:
        return cache[key]

    # Check any successful cache entry starting with same title to avoid extra API calls
    # (optional optimization)
    for ck in list(cache.keys()):
        if ck.startswith(f"{title}___") and cache[ck].get("Response")=="True":
            # If we have any successful entry for this title, reuse if year is empty or matches loosely
            if not year or year in ck:
                pass # could return but we prefer exact year

    def get_variants(t):
        v=[t]
        c=clean_title_movie(t)
        if c!=t and c not in v:
            v.append(c)
        if '  ' in t:
            first=t.split('  ')[0].strip()
            if first and first not in v:
                v.append(first)
        return v

    for var in get_variants(title):
        tries=[]
        if year and re.match(r'^\d{4}$', str(year).strip()):
            tries.append({"t":var,"y":str(year).strip()})
        tries.append({"t":var})
        for params in tries:
            params.update({"apikey":OMDB_API_KEY,"plot":"full"})
            try:
                r=session.get(OMDB_URL, params=params, timeout=12)
                if r.status_code==200:
                    d=r.json()
                    if d.get("Response")=="True":
                        cache[key]=d
                        print(f"  [OMDb] Found t='{var}' y='{params.get('y','')}' -> {d.get('Title')} ({d.get('Year')})")
                        time.sleep(0.35)
                        return d
            except Exception as e:
                print(f"  OMDb error t={var}: {e}")
            time.sleep(0.2)

        # Search fallback
        try:
            params={"apikey":OMDB_API_KEY,"s":var}
            if year and re.match(r'^\d{4}$', str(year).strip()):
                params["y"]=str(year).strip()
            r=session.get(OMDB_URL, params=params, timeout=12)
            if r.status_code==200:
                d=r.json()
                if d.get("Response")=="True" and d.get("Search"):
                    imdb_id=d["Search"][0].get("imdbID")
                    if imdb_id:
                        r2=session.get(OMDB_URL, params={"apikey":OMDB_API_KEY,"i":imdb_id,"plot":"full"}, timeout=12)
                        if r2.status_code==200:
                            d2=r2.json()
                            if d2.get("Response")=="True":
                                cache[key]=d2
                                print(f"  [OMDb] Found via search s='{var}' -> {d2.get('Title')} ({d2.get('Year')})")
                                time.sleep(0.35)
                                return d2
        except Exception as e:
            print(f"  OMDb search error s={var}: {e}")
        time.sleep(0.2)

    print(f"  [OMDb] !! NOT FOUND {title} ({year})")
    cache[key]={"Response":"False","Error":"Not found","Title":title,"Year":year}
    return cache[key]

# =============================================================================
# TVMaze (Series)
# =============================================================================
def fetch_tvmaze_search(title, session):
    candidates=[]
    if title=="Anne":
        candidates=["Anne with an E","Anne","Anne 2017"]
    elif title=="24":
        candidates=["24","24 TV series"]
    elif title=="Kingdom":
        candidates=["Kingdom Korean","Kingdom 2019","Kingdom"]
    elif title=="Money Heist":
        candidates=["La Casa de Papel","Money Heist"]
    elif "Protector" in title:
        candidates=["Hakan Muhafiz","The Protector 2018",title]
    elif "Bridge" in title:
        candidates=["Bron Broen","The Bridge",title]
    else:
        candidates.append(title)
        cleaned=clean_title_series(title)
        if cleaned!=title:
            candidates.append(cleaned)
        stripped=get_paren_stripped(cleaned)
        if stripped!=cleaned and stripped!=title:
            candidates.append(stripped)
    seen=[]
    for c in candidates:
        if c not in seen and c.strip():
            seen.append(c)
    candidates=seen

    for q in candidates:
        try:
            resp=session.get(TVMAZE_SEARCH_URL, params={"q":q}, timeout=10)
            if resp.status_code==200:
                results=resp.json()
                if results:
                    if title in TVMAZE_CORRECTIONS:
                        target=TVMAZE_CORRECTIONS[title]
                        for item in results:
                            if item['show']['id']==target:
                                return item['show'], q, results
                    return results[0]['show'], q, results
        except Exception as e:
            print(f"  TVMaze search fail {q}: {e}")
        time.sleep(0.4)
    return None,None,[]

def fetch_tvmaze_crew_cast(show_id, session):
    crew,cast=[],[]
    try:
        r=session.get(TVMAZE_CREW_URL.format(show_id), timeout=10)
        if r.status_code==200:
            crew=r.json()
    except: pass
    time.sleep(0.25)
    try:
        r=session.get(TVMAZE_CAST_URL.format(show_id), timeout=10)
        if r.status_code==200:
            cast=r.json()
    except: pass
    time.sleep(0.25)
    return crew,cast

def fetch_tvmaze_by_id(show_id, session):
    try:
        r=session.get(TVMAZE_SHOW_URL.format(show_id), timeout=10)
        if r.status_code==200:
            return r.json()
    except: pass
    return None

def extract_tvmaze_fields(show, crew, cast):
    year=""
    if show.get("premiered"):
        m=re.search(r'^(19\d{2}|20\d{2})', show["premiered"])
        if m: year=m.group(1)
    genre=", ".join(show.get("genres",[]))
    rating=str(show["rating"]["average"]) if show.get("rating") and show["rating"].get("average") is not None else ""
    runtime=f"{show['runtime']} min" if show.get("runtime") else f"{show['averageRuntime']} min" if show.get("averageRuntime") else ""
    country,studio="",""
    if show.get("network"):
        if show["network"].get("country"):
            country=show["network"]["country"].get("name","")
        studio=show["network"].get("name","")
    if show.get("webChannel"):
        if not country and show["webChannel"].get("country"):
            country=show["webChannel"]["country"].get("name","")
        if not studio:
            studio=show["webChannel"].get("name","")
        if not country and show["webChannel"]["name"] in ["Netflix","Hulu","Amazon Prime Video","Apple TV+","Disney+"]:
            country="United States"
    if not country:
        lang_map={"English":"United States","Korean":"South Korea","Spanish":"Spain","Turkish":"Turkey","Swedish":"Sweden"}
        country=lang_map.get(show.get("language",""), show.get("language",""))
    synopsis=strip_html(show.get("summary",""))
    poster=(show.get("image") or {}).get("original") or (show.get("image") or {}).get("medium") or ""
    producers, directors, creators=[],[],[]
    for member in crew:
        t=member.get("type","")
        name=member.get("person",{}).get("name","")
        if not name: continue
        if "Producer" in t: producers.append(name)
        if "Director" in t: directors.append(name)
        if "Creator" in t: creators.append(name)
    producer_str=", ".join(list(dict.fromkeys(producers))[:5])
    director_str=", ".join(list(dict.fromkeys(directors))[:3])
    if not director_str and creators:
        director_str=", ".join(list(dict.fromkeys(creators))[:3])
    cast_str=", ".join([c.get("person",{}).get("name","") for c in cast[:8] if c.get("person",{}).get("name")])
    if not producer_str and creators:
        producer_str=", ".join(creators[:3])
    return {
        "Year": year, "Genre": genre, "Rating": rating, "Runtime": runtime,
        "Country": country, "Studio": studio, "Synopsis": synopsis,
        "Poster URL": poster, "Producer": producer_str,
        "Director": director_str, "Cast": cast_str,
    }

# =============================================================================
# Main Enrichment Logic
# =============================================================================
def enrich_movies(input_path, output_dir, omdb_cache, session):
    print(f"\n=== Enriching Movies: {input_path} ===")
    # Read with fallback encodings
    rows=[]
    for enc in ['windows-1252','utf-8-sig','latin-1','windows-1256']:
        try:
            with open(input_path,'r',encoding=enc) as f:
                reader=csv.DictReader(f)
                if reader.fieldnames is None:
                    f.seek(0)
                    reader=csv.reader(f)
                    all_rows=list(reader)
                    # l1.csv has strange structure
                    if "Cinefilm Archive" in ",".join(all_rows[0]):
                        # l1 format
                        data_rows=all_rows[4:]
                        for r in data_rows:
                            if len(r)<2: continue
                            title=r[1].strip()
                            m=re.search(r'Year:\s*(\d{4})', r[2] if len(r)>2 else "")
                            year=m.group(1) if m else ""
                            rows.append({"Movie Title":title,"Release Year":year,"Total Size":r[3] if len(r)>3 else "","Folder Paths":r[4] if len(r)>4 else "","Raw":r})
                    else:
                        # generic
                        for r in all_rows[1:]:
                            if len(r)>=2:
                                rows.append({"Movie Title":r[1] if len(r)>1 else "","Release Year":r[2] if len(r)>2 else "","Total Size":"","Folder Paths":r[-1] if len(r)>9 else ""})
                else:
                    rows=list(reader)
            if rows:
                print(f"Read {len(rows)} rows with {enc}")
                break
        except Exception as e:
            print(f"Failed {enc}: {e}")

    enriched=[]
    missing=[]
    found=0
    for idx,row in enumerate(rows,1):
        title=row.get("Movie Title","") or row.get("Title","") or row.get("title","")
        title=title.strip()
        year=row.get("Release Year","") or row.get("Year","") or row.get("year","")
        year=year.strip()
        # Skip empty
        if not title:
            continue
        # Skip placeholder like "???? ???"
        if set(title)=={"?"} or len(title)<2:
            continue

        print(f"[{idx}/{len(rows)}] {title} ({year})")
        data=fetch_omdb(title, year, session, omdb_cache)
        is_ok=data.get("Response")=="True"
        if is_ok:
            found+=1
        else:
            missing.append({
                "Title": title,
                "Year": year,
                "Total Size": row.get("Total Size","") or row.get("Total Size",""),
                "Folder Paths": row.get("Folder Paths","") or row.get("Sample Folder Path","") or row.get("Raw",""),
                "Reason": "در OMDb پیدا نشد"
            })

        def gc(k):
            v=data.get(k,"") if is_ok else ""
            return "" if v=="N/A" else v

        omdb_title=gc("Title")
        director=gc("Director")
        cast=gc("Actors")
        y_raw=gc("Year") or year
        m=re.search(r'(\d{4})', y_raw) if y_raw else None
        y=m.group(1) if m else y_raw
        genre=gc("Genre")
        rating=gc("imdbRating")
        runtime=gc("Runtime")
        country=gc("Country")
        synopsis=gc("Plot")
        poster=gc("Poster")

        enriched.append({
            "Title": title,
            "Shelf": "",
            "Row": "",
            "Director": director,
            "Cast": cast,
            "Year": y,
            "Genre": genre,
            "Rating": rating,
            "Runtime": runtime,
            "Country": country,
            "Synopsis": synopsis,
            "Poster URL": poster,
            "Original Title": omdb_title or title,
            "Total Size": row.get("Total Size",""),
            "Folder Paths": row.get("Folder Paths","") or row.get("Sample Folder Path","") or "",
        })

        if idx%30==0:
            Path(output_dir+"/omdb_cache.json").write_text(json.dumps(omdb_cache, ensure_ascii=False, indent=2), encoding='utf-8')

    return enriched, missing, found

def enrich_series(input_path, output_dir, tvmaze_cache, session):
    print(f"\n=== Enriching Series: {input_path} ===")
    rows=[]
    with open(input_path,'r',encoding='utf-8-sig', errors='ignore') as f:
        try:
            reader=csv.DictReader(f)
            rows=list(reader)
            # Filter empty titles
            rows=[r for r in rows if r.get("Series Name","") or r.get("Title","")]
            if not rows:
                raise ValueError("empty")
        except:
            f.seek(0)
            # Try windows-1252 for series archive
            f2=open(input_path,'r',encoding='windows-1252')
            reader2=csv.DictReader(f2)
            rows=list(reader2)

    print(f"Read {len(rows)} series")

    enriched=[]
    missing=[]
    found=0
    for idx,row in enumerate(rows,1):
        title=row.get("Series Name","") or row.get("Title","")
        title=title.strip()
        if not title or title=="A" or len(title)<2:
            # Special handling for broken entries
            sample=row.get("Sample Folder Path","")
            if not title and sample:
                # Guess from folder
                title=sample.split("\\")[-1] if "\\" in sample else sample
            else:
                if title!="A":
                    continue

        print(f"[{idx}/{len(rows)}] {title}")

        show=None
        crew,cast_list=[],[]

        # Correction ID
        if title in TVMAZE_CORRECTIONS and title not in tvmaze_cache:
            print(f"  -> correction ID {TVMAZE_CORRECTIONS[title]}")
            show=fetch_tvmaze_by_id(TVMAZE_CORRECTIONS[title], session)
            if show:
                crew,cast_list=fetch_tvmaze_crew_cast(show['id'], session)
                tvmaze_cache[title]={"show":show,"crew":crew,"cast":cast_list}

        if title in tvmaze_cache:
            show=tvmaze_cache[title]["show"]
            crew=tvmaze_cache[title].get("crew",[])
            cast_list=tvmaze_cache[title].get("cast",[])
            print(f"  -> cache {show.get('name')} ({show.get('premiered')})")
        else:
            if not show:
                show,used_q,_=fetch_tvmaze_search(title, session)
            if not show:
                print(f"  !! NOT FOUND {title}")
                missing.append({
                    "Title": title,
                    "Sample Folder Path": row.get("Sample Folder Path",""),
                    "Seasons Available": row.get("Seasons Available",""),
                    "Total Size": row.get("Total Size",""),
                    "Reason": "در TVMaze پیدا نشد"
                })
                new_row=row.copy()
                for k in ["Producer","Director","Cast","Year","Genre","Rating","Runtime","Country","Studio","Synopsis","Poster URL"]:
                    new_row[k]=""
                enriched.append(new_row)
                continue
            print(f"  -> found via '{used_q}': {show.get('name')} ({show.get('premiered')})")
            crew,cast_list=fetch_tvmaze_crew_cast(show['id'], session)
            tvmaze_cache[title]={"show":show,"crew":crew,"cast":cast_list,"query":used_q}

        extra=extract_tvmaze_fields(show, crew, cast_list)
        new_row=row.copy()
        for k,v in extra.items():
            new_row[k]=v
        enriched.append(new_row)
        found+=1

        if idx%10==0:
            Path(output_dir+"/tvmaze_cache.json").write_text(json.dumps(tvmaze_cache, ensure_ascii=False, indent=2), encoding='utf-8')

    return enriched, missing, found

def write_outputs(enriched, missing, base_name, output_dir, is_movie=True):
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Main enriched
    if enriched:
        # Determine fieldnames
        if is_movie:
            fieldnames=MOVIE_IMAGE_COLS
            # Ensure all keys exist
            for r in enriched:
                for fn in fieldnames:
                    if fn not in r:
                        r[fn]=""
        else:
            # Series: original + extra
            original_keys=list(enriched[0].keys())
            extra=["Producer","Director","Cast","Year","Genre","Rating","Runtime","Country","Studio","Synopsis","Poster URL"]
            fieldnames=original_keys
            for e in extra:
                if e not in fieldnames:
                    fieldnames.append(e)

        # CSV
        csv_path=output_dir/f"{base_name}-enriched-final.csv"
        with open(csv_path,'w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(enriched)
        print(f"CSV -> {csv_path}")

        # XLSX
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter
            wb=openpyxl.Workbook()
            ws=wb.active
            ws.title="Enriched"
            for ci,fn in enumerate(fieldnames,1):
                c=ws.cell(row=1,column=ci,value=fn)
                c.font=Font(bold=True,color="FFFFFF")
                c.fill=PatternFill(start_color="2F5597",end_color="2F5597",fill_type="solid")
                c.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
            for ri,r in enumerate(enriched,2):
                for ci,fn in enumerate(fieldnames,1):
                    ws.cell(row=ri,column=ci,value=r.get(fn,""))
            for ci,fn in enumerate(fieldnames,1):
                ws.column_dimensions[get_column_letter(ci)].width=30 if fn not in ["Synopsis","Folder Paths","Sample Folder Path","Season & Episode Breakdown"] else 60
            ws.freeze_panes="A2"
            ws.auto_filter.ref=ws.dimensions
            xlsx_path=output_dir/f"{base_name}-enriched-final.xlsx"
            wb.save(xlsx_path)
            print(f"XLSX -> {xlsx_path}")
        except Exception as e:
            print(f"XLSX error {e}")

    # Missing
    if missing:
        missing_csv=output_dir/f"{base_name}-MISSING-to-fix.csv"
        with open(missing_csv,'w',encoding='utf-8-sig',newline='') as f:
            fieldnames=list(missing[0].keys())
            w=csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(missing)
        print(f"Missing CSV -> {missing_csv} ({len(missing)} items)")

        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill
            from openpyxl.utils import get_column_letter
            wb=openpyxl.Workbook()
            ws=wb.active
            ws.title="Missing"
            fieldnames=list(missing[0].keys())
            for ci,fn in enumerate(fieldnames,1):
                c=ws.cell(row=1,column=ci,value=fn)
                c.font=Font(bold=True,color="FFFFFF")
                c.fill=PatternFill(start_color="C00000",end_color="C00000",fill_type="solid")
            for ri,r in enumerate(missing,2):
                for ci,fn in enumerate(fieldnames,1):
                    ws.cell(row=ri,column=ci,value=r.get(fn,""))
            for ci in range(1,len(fieldnames)+1):
                ws.column_dimensions[get_column_letter(ci)].width=35
            ws.column_dimensions['D'].width=80
            xlsx_path=output_dir/f"{base_name}-MISSING-to-fix.xlsx"
            wb.save(xlsx_path)
            print(f"Missing XLSX -> {xlsx_path}")
        except Exception as e:
            print(f"Missing XLSX error {e}")

# =============================================================================
# CLI Entry
# =============================================================================
def main():
    parser=argparse.ArgumentParser(description="Cinefilm Archive Complete Enricher")
    parser.add_argument('--input', '-i', required=True, help='Input CSV file')
    parser.add_argument('--type', '-t', choices=['movie','series','auto'], default='auto', help='File type (auto detect)')
    parser.add_argument('--output-dir', '-o', default='output', help='Output directory')
    parser.add_argument('--omdb-cache', default='output/omdb_cache.json', help='OMDb cache file')
    parser.add_argument('--tvmaze-cache', default='output/tvmaze_cache.json', help='TVMaze cache file')
    args=parser.parse_args()

    input_path=Path(args.input)
    if not input_path.exists():
        print(f"Input not found: {input_path}")
        return

    output_dir=Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load caches
    omdb_cache={}
    tvmaze_cache={}
    if Path(args.omdb_cache).exists():
        try:
            omdb_cache=json.loads(Path(args.omdb_cache).read_text(encoding='utf-8'))
            print(f"OMDb cache loaded: {len(omdb_cache)}")
        except: pass
    if Path(args.tvmaze_cache).exists():
        try:
            tvmaze_cache=json.loads(Path(args.tvmaze_cache).read_text(encoding='utf-8'))
            print(f"TVMaze cache loaded: {len(tvmaze_cache)}")
        except: pass

    session=requests.Session()
    session.headers.update({"User-Agent":"CinefilmArchiveEnricher/1.0"})

    file_type=args.type
    if file_type=='auto':
        file_type=detect_file_type(input_path)
        print(f"Auto detected type: {file_type}")

    base_name=input_path.stem

    if file_type=='movie':
        enriched,missing,found=enrich_movies(input_path, args.output_dir, omdb_cache, session)
        print(f"\nMovies: Found {found}/{len(enriched)} ({found/len(enriched)*100:.1f}%)")
        write_outputs(enriched, missing, base_name, args.output_dir, is_movie=True)
        # Save cache
        Path(args.omdb_cache).write_text(json.dumps(omdb_cache, ensure_ascii=False, indent=2), encoding='utf-8')
    else:
        enriched,missing,found=enrich_series(input_path, args.output_dir, tvmaze_cache, session)
        print(f"\nSeries: Found {found}/{len(enriched)} ({found/len(enriched)*100:.1f}%)")
        write_outputs(enriched, missing, base_name, args.output_dir, is_movie=False)
        Path(args.tvmaze_cache).write_text(json.dumps(tvmaze_cache, ensure_ascii=False, indent=2), encoding='utf-8')

    print("\n=== Done ===")
    print(f"Enriched file: {output_dir}/{base_name}-enriched-final.xlsx")
    if missing:
        print(f"Missing file to fix: {output_dir}/{base_name}-MISSING-to-fix.xlsx (with hard drive paths)")

if __name__=="__main__":
    main()
